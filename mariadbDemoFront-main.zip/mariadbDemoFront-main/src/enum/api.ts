const prefix = "http://localhost:8877/"
export const enum apis{
    test = `${prefix}Reservations/test`
}