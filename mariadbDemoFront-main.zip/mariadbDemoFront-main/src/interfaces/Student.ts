export interface Student {
    student_id: string;     // 學號（VARCHAR(10)）
    student_name: string;   // 學生姓名（VARCHAR(50)）
}